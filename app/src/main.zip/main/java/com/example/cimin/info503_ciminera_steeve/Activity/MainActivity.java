package com.example.cimin.info503_ciminera_steeve.Activity;

import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatDelegate;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.cimin.info503_ciminera_steeve.R;
import com.example.cimin.info503_ciminera_steeve.model.JsonDrawerAdapter;
import com.example.cimin.info503_ciminera_steeve.model.JsonHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<JSONObject> drawerItemList = new ArrayList<>();
    private DrawerLayout myDrawerLayout;
    private JsonHandler jsonhandler = new JsonHandler(this);
    ListView mListView = (ListView) findViewById(R.id.drawerLv);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);

        myDrawerLayout = (DrawerLayout) findViewById(R.id.myDrawerLayout);
        Toolbar mainToolbar = (android.support.v7.widget.Toolbar) findViewById(R.id.main_toolbar);
        setSupportActionBar(mainToolbar);

        //on rempli le drawer
        try {
            JSONObject drawerItemJson = jsonhandler.retrieveJSON(jsonhandler.GetJSONid("drawer_items"));
            for(int i=0; i<drawerItemJson.getJSONArray("items").length(); i++){
                drawerItemList.add(drawerItemJson.getJSONArray("items").getJSONObject(i));
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonDrawerAdapter jda = new JsonDrawerAdapter(this, drawerItemList);
        mListView.setAdapter(jda);

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView parent, View view,
                                    int position, long id) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.hamburgerMenu:
                //si le menu est ouvert, on le ferme
                if(myDrawerLayout.isDrawerOpen(Gravity.LEFT) || myDrawerLayout.isDrawerOpen(Gravity.RIGHT)){
                    myDrawerLayout.closeDrawer(Gravity.LEFT, true);
                }else{ //si le menu est fermé, on l'ouvre
                    myDrawerLayout.openDrawer(Gravity.LEFT, true);
                }
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private JSONObject getJSON(int id) throws IOException, JSONException {
        InputStream is = getResources().openRawResource(id);
        Writer writer = new StringWriter();
        char[] buffer = new char[1024];
        try {
            Reader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            int n;
            while ((n = reader.read(buffer)) != -1) {
                writer.write(buffer, 0, n);
            }
        } finally {
            is.close();
        }

        return new JSONObject(writer.toString());
    }
}
